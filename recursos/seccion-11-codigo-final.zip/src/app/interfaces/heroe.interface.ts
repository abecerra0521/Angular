export interface Heroe {
    name: string;
    company: string;
    bio: string;
    key$?: string
};
